%%
% $$ (\alpha = \hat \alpha ) \wedge ( m( x ) = m( y ) ) \wedge ( 0 \leq m( x ) ) $$
k = 1;
while k<=m_x 
    alpha = x( k ) * y( k ) + alpha;
    k = k+1;
end

alpha_out = alpha;



